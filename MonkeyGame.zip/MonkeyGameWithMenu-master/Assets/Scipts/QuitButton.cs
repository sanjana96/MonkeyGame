﻿using UnityEngine;
using System.Collections;

public class QuitButton : MonoBehaviour {

	public void quit () 
	{
		Application.Quit();
    }
}
