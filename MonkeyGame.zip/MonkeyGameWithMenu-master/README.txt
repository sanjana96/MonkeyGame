1) Game can be edited by o=modifying the contents of the .unity files present in the Assets folder.
2) The respective code can be found in the Assets/Scripts folder.
3) To test the game, transfer the MonkeyGameWithMenu.apk file to your Android device and install it on phone.
4) Installation files for Windows Phone, Windows 8.1, iPhone shall be updated soon..